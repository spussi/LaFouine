# NB: Pour les coordonnees (0, 0) est le coins en haut a gauche.

class Bateau:
    def __init__(self, l, o, x, y, id):
        self.l = l
        self.x = x
        self.y = y
        self.o = o
        self.id = id

        self.corps = [] # Le corps du du bateau est en fait une liste qui contient les coordonnees des cases occupees par le bateau.
        # On cree le bateau differement en fonction de son orientation.
        if self.o == 0: # Orientation horizontale.
            for i in range(0, self.l):
                partie = (self.x + i, self.y)
                self.corps.append(partie)
        if self.o == 1: # Orientation verticale.
            for i in range(0, self.l):
                partie = (self.x, self.y + i)
                self.corps.append(partie)

    def print(self): # Juste pour debugger.
        for t in self.corps:
            print(t)
    
    def endommager(self, x, y):
        # On supprime la partie du bateau qui est detruite.
        for partie in self.corps:
            if partie[0] == x and partie[1] == y: # Oui le bateau est separe par un vide, un trou quoi.
                self.corps.remove(partie)
    
    def est_mort(self): # Si toutes les parties du bateau son detruites.
        return len(self.corps) == 0