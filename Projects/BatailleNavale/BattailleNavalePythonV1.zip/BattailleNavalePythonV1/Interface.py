import tkinter as tk
from tkinter import ttk
from Bateau import *
from Matrice import *
import os

"""
window = tk.Tk()
window.geometry("1920x1080")
window.columnconfigure(2, weight=1) #Il y a 2+1 colonnes
window.rowconfigure(2, weight=1) #Il y a 2+1 lignes
"""

#Une classe auto contenue dans son widget quiva nous remplir un tableau de boutons ou autres
class tableau(ttk.Frame):
    def __init__(self, container, buttonClass):
        super().__init__(container)

        #On définit la quantité de colonnes et de lignes
        self.columns = 10
        self.rows = 10

        options = {'padx': 5, 'pady': 5} #Jsp pk C là

        self.columnconfigure(self.columns, weight=1)
        self.rowconfigure(self.rows, weight=1)

        """ Python ne trouve pas le fichier pour je ne sais quelle raison, il se peut que ça aie à voir avec OneDrive.
        backgroundIamge = tk.PhotoImage(file = "background.gif")
        background = Label(root, image = backgroundIamge)
        background.place(x = 0, y = 0)
        """

        #Code temporaire pour placer tous les boutons sans se casser le crâne
        for r in range(self.rows):
            for c in range(self.columns):
                b = buttonClass(self, c, r) #Création du bouton, buttonClass permet de placer des boutons différents
                b.grid(column = c, row = r) #Placage du bouton
                #Ne pas s'attendre à trouver le bouton grâce à la variable

                """
                varName = f"var_{r}{c}"
                exec(f"{varName} = ttk.Label(text='r={r}, c={c}').grid(column={c}, row={r})")
                """

#Classe des boutons de ciblage, cliquables pour tirer
class targetingBtn(tk.Button):
    def __init__(self, container, column, row):

        self.height = 3 #à la fois hauteur et largeur

        super().__init__(container, height=self.height, width=self.height*2, command=self.onClick)

        #On note les coordonnées du bouton à l'intérieur de chaque bouton
        self.column = column
        self.row = row

    #Méthode universelle qui appelle la méthode qu'on veut pour modifications futures, ou pour effectuer plusieurs action quand le bouton est pressé
    def onClick(self):
        self.printBtnCoordinates(self.row, self.column)

    #Méthode qui print la position du bouton pressé, POUR DEBUG
    def printBtnCoordinates(self, row, column):
        print(f"Button pressed at: {row} ; {column}")

class statusBtn(tk.Button):
    def __init__(self, container, column, row):

        self.height = 3 #à la fois hauteur et largeur

        super().__init__(container, height=self.height, width=self.height*2, command=self.onClick)

        #On note les coordonnées du bouton à l'intérieur de chaque bouton
        self.column = column
        self.row = row

    #Méthode universelle qui appelle la méthode qu'on veut pour modifications futures, ou pour effectuer plusieurs action quand le bouton est pressé
    def onClick(self):
        self.printBtnCoordinates(self.row, self.column)
        

    #Méthode qui print la position du bouton pressé, POUR DEBUG
    def printBtnCoordinates(self, row, column):
        print(f"Button pressed at: {row} ; {column}")

#Classe bouton pour séléctionner le bateau que l'on veut placer
class boatSelectBtn(ttk.Button):
    def __init__(self, container, length):
        super().__init__(container, text=str(length), command=self.onClick)

        self.length = length

    #Méthode universelle qui appelle la méthode qu'on veut pour modifications futures, ou pour effectuer plusieurs action quand le bouton est pressé
    def onClick(self):
        self.printBoatType()

    def printBoatType(self):
        print(f"Boat of size {self.length} selected.")

#Classe pour faire la liste qui permet de séléctionner les boutons
class boatSelectListbox(tk.Frame):
    def __init__(self, container, boatList): #boatList est une liste contenant chaque bateau, représenté par sa longueur
        self.boatList = boatList
        super().__init__(container, height=len(boatList))
        #On place les bateaux dans la listbox
        for boat in range(len(boatList)):
            boatSelectBtn(self, boatList[boat]).grid(row=boat)


"""
boatList = boatSelectListbox(window, [2, 3, 3, 4, 5])
boatList.grid(column=1, row=1)

TargetingFrame = tableau(window, targetingBtn)
StatusFrame = tableau(window, statusBtn)

TargetingFrame.grid(column=0, row=0)
StatusFrame.grid(column=3, row=0)

window.mainloop()
"""

# Modification pour la classe Jeu
class Tableau(ttk.Frame):
    def __init__(self, container, buttonClass, background):
        super().__init__(container)

        #On définit la quantité de colonnes et de lignes
        self.columns = 10
        self.rows = 10

        self.tableau = [[0 for _ in range(self.columns)] for _ in range(self.rows)]

        self.columnconfigure(self.columns, weight=1)
        self.rowconfigure(self.rows, weight=1)

        for r in range(self.rows):
            for c in range(self.columns):
                b = buttonClass(self, c, r, background) #Création du bouton, buttonClass permet de placer des boutons différents
                self.tableau[r][c] = b
                b.grid(column = c, row = r) #Placage du bouton
                #Ne pas s'attendre à trouver le bouton grâce à la variable, utiliser le tableau

#Classe des boutons de ciblage, cliquables pour tirer
class TargetingBtn(tk.Button):
    def __init__(self, container, column, row, background):

        self.height = 46 #à la fois hauteur et largeur

        super().__init__(container, height=self.height, width=self.height, command=self.onClick, image=background)

        #On note les coordonnées du bouton à l'intérieur de chaque bouton
        self.column = column
        self.row = row
        self.coord = 0

        self.clicked = False

    #Méthode universelle qui appelle la méthode qu'on veut pour modifications futures, ou pour effectuer plusieurs action quiand le bouron est pressé
    def onClick(self):
        self.clicked = True

    def get_coord(self):
        return [self.row, self.column]

    def cancel(self):
        self.clicked = False

    #Méthode qui print la position du bouton pressé, POUR DEBUG
    def printBtnCoordinates(self, row, column):
        print(f"Button pressed at: {row+1} ; {column+1}")

#Classe bouton pour séléctionner le bateau que l'on veut placer
class BoatSelectBtn(ttk.Button):
    def __init__(self, container, length):
        super().__init__(container, text=str(length), command=self.onClick)

        self.length = length
        self.clicked = False
        self.container = container

    def enableBtn(self): self["state"] = "normal"
    def disableBtn(self): self["state"] = "disabled"

    #Méthode universelle qui appelle la méthode qu'on veut pour modifications futures, ou pour effectuer plusieurs action quiand le bouron est pressé
    def onClick(self):
        self.clicked = True

    def cancel(self):
        self.clicked = False

    def get_boat_size(self):
        return self.length

    def printBoatType(self):
        print(f"Boat of size {self.length} selected.")

class StatusBtn(tk.Button):
    def __init__(self, container, column, row, background):

        self.height = 46 #à la fois hauteur et largeur
        
        super().__init__(container, height=self.height, width=self.height, command=self.onClick, image=background)

        #On note les coordonnées du bouton à l'intérieur de chaque bouton
        self.column = column
        self.row = row
        self.coord = 0

        self.clicked = False

    def enableBtn(self): self["state"] = "normal"
    def disableBtn(self): self["state"] = "disabled"

    #Méthode universelle qui appelle la méthode qu'on veut pour modifications futures, ou pour effectuer plusieurs action quiand le bouron est pressé
    def onClick(self):
        self.clicked = True
    
    def get_coord(self):
        return [self.row, self.column]
    
    def cancel(self):
        self.clicked = False
    
    #Méthode qui print la position du bouton pressé, POUR DEBUG
    def printBtnCoordinates(self, row, column):
        print(f"Button pressed at: {row+1} ; {column+1}")

#Classe pour faire la liste qui permet de séléctionner les boutons
class BoatSelectListbox(tk.Frame):
    def __init__(self, container, boatList): #boatList est une liste contenant chaque bateau, représennté par sa longueur
        super().__init__(container, height=len(boatList), bg='blue',bd=15 ,relief=tk.GROOVE)

        self.boats_list = []

        #On place les bateaux dans la listbox
        for boat in range(len(boatList)):
            b = BoatSelectBtn(self, boatList[boat])
            b.grid(row=boat)
            self.boats_list.append(b)

        self.BoatSpinBtnCallable = BoatSpinBtn(self)
        self.BoatSpinBtnCallable.grid(column=1, row=0, rowspan=2)

        self.BoatUndoBtnCallable = BoatUndoBtn(self)
        self.BoatUndoBtnCallable.grid(column=1, row=2, rowspan=2)

        self.BoatConfirmPlacementBtnCallable = BoatConfirmPlacementBtn(self)
        self.BoatConfirmPlacementBtnCallable.grid(column=2, row=0, rowspan=self.grid_size()[1])

class BoatSpinBtn(ttk.Checkbutton):
    def __init__(self, container):      
        self.CheckButtonValue = tk.IntVar()
        super().__init__(container, text="Horizontal", command=self.onClick, variable=self.CheckButtonValue, onvalue=1, offvalue=0)

    #Méthode universelle qui appelle la méthode qu'on veut pour modifications futures, ou pour effectuer plusieurs action quiand le bouron est pressé
    def onClick(self):
        self.switchText()

    def switchText(self):
        if self.CheckButtonValue.get() == 0: self.config(text="Horizontal")
        elif self.CheckButtonValue.get() == 1: self.config(text="Vertical")
        else: self.config(textd="Ceci ne devrait jamais apparaître")

class BoatUndoBtn(ttk.Button): #Bouton pour annuler le placement d'un bateau
    def __init__(self, container):
        super().__init__(container, text = "Cancel", command=self.onClick)
        self.clicked = False

    def onClick(self):
        self.clicked = True
    
    def get_coord(self):
        return [self.row, self.column]
    
    def cancel(self):
        self.clicked = False

class BoatConfirmPlacementBtn(ttk.Button):
    def __init__(self, container):
        super().__init__(container, text="Confirm boat coordinates", command=self.onClick, state="disabled")
        self.clicked = False

    def enableBtn(self): self["state"] = "normal"
    def disableBtn(self): self["state"] = "disabled"

    def onClick(self):
        self.clicked = True
    
    def get_coord(self):
        return [self.row, self.column]
    
    def cancel(self):
        self.clicked = False

class FenetreDeFin(tk.Toplevel):
    def __init__(self, container, gagnant):
        super().__init__(container)
        self.container = container

        self.height = 100
        self.width = 300

        self.title("Fin de la partie")
        self.geometry(f"{self.width}x{self.height}+{int(self.container.winfo_screenwidth()/2 - self.width/2)}+{int(self.container.winfo_screenheight()/2 - self.height/2)}")
        self.rowconfigure(2)
        self.columnconfigure(2)

        self.texte = tk.Label(self, text=f"{gagnant} a gagné.")
        self.texte.grid(row=0, column=0, columnspan=2)
        
        self.CloseBtn = ttk.Button(self, text="Sortir", command=lambda: self.container.destroy())
        self.CloseBtn.grid(row=1, column=1)
        
        #self.RestartBtn = ttk.Button(self, text="Recommencer", command=lambda: self.restartGame())
        #self.RestartBtn.grid(row=1, column=0)

    def restartGame(self): #! NE MARCHE PAS !
        os.startfile(fr"{os.getcwd()}\Bataille navale\BattailleNavallePython\Jeu.py")
        self.container.destroy()
        