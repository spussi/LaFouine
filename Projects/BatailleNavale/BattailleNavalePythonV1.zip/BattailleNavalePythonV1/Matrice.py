class Matrice:
    def __init__(self, l, c):
        self.l = l # Lignes
        self.c = c # Colonnes.
        self.mort = False
        self.table = [[0 for _ in range(self.c)] for _ in range(self.l)]
        # Deux structures pour les bateaux, pour gerer differentes fonctions. 
        self.bateaux_dict = {} # Un dictionnaire qui contient tous les couples de {identite bateau: classe du bateau}.
        self.bateaux = [] # Une liste qui contient les bateaux.

    def ajouter_bateau(self, bateau): # Ajouter bateau dans dictionnaire.
        self.bateaux_dict.update({bateau.id: bateau})

    def suprimer_bateau(self, bateau): # Supprimer bateau du dictionnaire.
        self.bateaux_dict.pop(bateau.id)

    def disparait(self,Jeu):
        Jeu.Cross_Image.widget.destroy()
    """
    def tirer(self,Jeu,bateau):
        for i in range(bateau.l):
            Jeu.statusFrame.tableau[][]["image"] = Jeu.Cross_Image
    """

    """
    0: On a déjà tiré ici
    1: Touché de l'eau
    2: Touché un bateau
    3: Coulé un bateau
    """

    # Fonction pour prendre des degats.
    def prendre_degat(self, x, y, frame, WhiteCross_Image, Cross_Image):
        if not (0 <= x < len(self.table[0]) and 0 <= y < len(self.table)):
            return 0

        if self.table[y][x] == 0: # Check si la case visée est de l'eau, on print "Eau".
            print("Eau En: " + str(x) + "; " + str(y))
            self.table[y][x] = 3
            self.print_matrice()
            frame.tableau[y][x]["image"] = WhiteCross_Image
            return 1 #On précise si le tir s'est pu faire 1 signifie qu'on a touché de l'eau
        if self.table[y][x] == 3 or self.table[y][x] == 4:
            print("On a déjà tiré ici. En: " + str(x) + "; " + str(y))
            return 0 #0 veut dire qu'on a déjà tiré ici
        else:
            print("Touché En: " + str(x) + "; " + str(y)) # Sinon on print "Touché".
            id = self.chercher_bateau(x, y) # On recupere l'identite du bateau.
            self.bateaux_dict[id].endommager(x, y) # On attaque le bateau en question.
            self.table[y][x] = 4 # La case visee devient maintenant juste de l'eau, un trou dans le bateau quoi.
            self.print_matrice()
            frame.tableau[y][x]["image"] = Cross_Image
            # Si le bateau est mort / completement detruit.

            if self.bateaux_dict[id].est_mort():
                self.bateaux.remove(self.bateaux_dict[id]) # On enleve le bateau en question de la liste bateau.
                self.suprimer_bateau(self.bateaux_dict[id]) # On l'enleve aussi dans le dictionnaire des bateaux.
                print(f"Bateau elimine: il reste {len(self.bateaux)} bateau(x).\n") # On print qu'un bateau
                if len(self.bateaux) == 0: # Si le jeu est vide <=> tous les bateaux sont detruits <=> il n'y a plus de bateau
                    self.mort = True # Le jeu est mort.
                    print("Jeu mort.")
                return 3 #4 veut dire qu'on a touché et coulé un bateau
            return 2 #2 veut dire qu'on a touché un bateau

        #self.print_matrice() # Pour debugger.

    def chercher_bateau(self, x, y): # Fonction pour chercher un bateau, etant donnee des coordonnees (x, y) arbitraire.
        if self.table[y][x] == 0: # On verifie si c'est pas de l'eau.
            print(f"({x}, {y}): eau.")
            return None
        else:
            i = 0
            index = None
            # Iteration pour cherche le bateau en question. Cette verification marche, car les bateaux ne se superposent pas.
            while i < len(self.bateaux):
                for partie in self.bateaux[i].corps:
                    if partie[0] == x and partie[1] == y:
                        index = i
                        break
                i += 1

            return self.bateaux[index].id # Renvoie l'identite du bateau.

    def check_taille(self, bateau): # Fonction pour checker la taille du bateau -> verifier qu'il ne deborde pas.
        s = 0
        if bateau.o == 0: # On check pour l'orientation horizontale.
            for i in range(bateau.l):
                s += self.table[bateau.y][bateau.x + i]
            return s == 0 # Verifie si ca deborde pas.

        if bateau.o == 1: # On check pour l'orientation verticale.
            for i in range(bateau.l):
                s += self.table[bateau.y + i][bateau.x]
            return s == 0

    def placer(self, bateau, Jeu=None): # Fonction pour placer un bateau dans une matrice.
        # Orientation horizontale.
        if bateau.o == 0:
            if bateau.x + bateau.l > 10: # Check si bateau deborde.
                print("Pas possible. Bateau déborde.")
                return False #On spécifie au reste du code si le bateau a été placé avec succès
            else:
                if self.check_taille(bateau): # S'il n'y a pas de superposition, on peut placer le bateau.
                    self.ajouter_bateau(bateau)
                    self.bateaux.append(bateau)
                    for i in range(bateau.l):
                        self.table[bateau.y][bateau.x + i] = 1
                        if Jeu != None:
                            if i==0: boat_image = boat_image = Jeu.boatEnd_Image
                            elif i == bateau.l-1: boat_image = Jeu.boatEndReversed_Image
                            else: boat_image = Jeu.boatMiddle_Image
                            #print(f"btn: {Jeu.statusFrame.tableau[bateau.y][bateau.x]}")
                            Jeu.statusFrame.tableau[bateau.y][bateau.x+i]["image"] = boat_image
                    return True
                else: # Sinon, on ne place pas.
                    print("Pas possible. Superposition de bateaux.")
                    return False

        # Orientation verticale.
        if bateau.o == 1:
            if bateau.y + bateau.l > 10: # Check si bateau deborde.
                print("Pas possible. Bateau déborde.")
                return False
            else:
                if self.check_taille(bateau): # Check s'il y a superposition ou pas.
                    self.ajouter_bateau(bateau)
                    self.bateaux.append(bateau)
                    for i in range(bateau.l):
                        self.table[bateau.y + i][bateau.x] = 1
                        if Jeu != None:
                            if i==0: boat_image = boat_image = Jeu.boatEnd_Image_turned
                            elif i == bateau.l-1: boat_image = Jeu.boatEndReversed_Image_turned
                            else: boat_image = Jeu.boatMiddle_Image_turned
                            Jeu.statusFrame.tableau[bateau.y+i][bateau.x]["image"] = boat_image
                    return True
                else:
                    print("Pas possible. Superposition de bateaux.")
                    return False

    def enlever(self, bateau, Jeu): #Fonction pour enlever le bateau entier, au cas où le joeur veut annuler le plaçage
        # Orientation horizontale.
        if bateau.o == 0:
            self.suprimer_bateau(bateau)
            self.bateaux.remove(bateau)
            for i in range(bateau.l):
                self.table[bateau.y][bateau.x + i] = 0 #Pratiquement la même chose que quand on ajoute, mais avecc moins de checks
                Jeu.statusFrame.tableau[bateau.y][bateau.x+i]["image"] = Jeu.water_image

        # Orientation verticale.
        if bateau.o == 1:
            self.suprimer_bateau(bateau)
            self.bateaux.remove(bateau)
            for i in range(bateau.l):
                self.table[bateau.y + i][bateau.x] = 0
                Jeu.statusFrame.tableau[bateau.y+i][bateau.x]["image"] = Jeu.water_image


        print(str(bateau) + " has been yeeted.")

    def effacer(self): # Fonction pour effacer completement la matrice.
        self.table = [[0 for _ in range(self.c)] for _ in range(self.l)]

    def print_bateaux(self): # Fonction pour debugger, qui print tous les bateaux.
        print(self.bateaux_dict)
        for e in self.bateaux:
            print(e)

    def print_matrice(self): # Fonction pour debugger, qui affiche le contenu de la matrice.
        #print("\n")
        for i in range(self.l):
            print(self.table[i])
        #print("\n")