from Matrice import *
from Bateau import *
from Interface import *
from random import *
import threading
from tkinter import PhotoImage
import tkinter as tk
import os

path = os.getcwd() #Comme ça tkinter trouve les fichiers des images avec n'import quelle machine, vu que PhotoImage demande des fois le path entier
print(path)
extraPath = r"" # ! à remplire selon la machine !

class Jeu:
    def __init__(self):
        # Variables essentielles.
        self.lignes = 10
        self.colonnes = 10
        self.running = True

        self.MODE = 0 # Variable pour les differents stades de jeux.
        resize_factor = 2
        # Instances de classes.
        self.matrice_joueur = Matrice(self.lignes, self.colonnes)
        self.matrice_ordinateur = Matrice(self.lignes, self.colonnes) # Va falloir ajouter des trucs pour qu'elle soit prete.
        """
        Documentation autour des matrices:
         0 = cellule occupée par deeau
         1 = cellule occupée par un bateau
         3 = cellule occupée par de l'eau dans laquelle on a déjà tiré
         4 = cellule occupée par un bateau dans laquelle on a déjà tiré
        """
        self.listOfBoats = [2, 3, 4, 5]

        self.window = tk.Tk()
        self.window.title("Battaille navale")

        self.window.geometry("1920x1080")
        self.window.state("zoomed")
        self.window.columnconfigure(2, weight=1) #Il y a 2+1 colonnes
        self.window.rowconfigure(1, weight=1) #Il y a 1+1 lignes

        self.background_image = PhotoImage(file=(path + extraPath + r"/Assets/background.gif"))
        self.background_label = tk.Label(self.window, image=self.background_image)
        self.background_label.place(relwidth=1, relheight=1)

        self.water_image = PhotoImage(file=(path + extraPath + r"/Assets/water.png"))
        self.water_image = self.water_image.subsample(resize_factor, resize_factor)

        #On déclare les différentes images qui vont être réutilisées:
        self.boatEnd_Image = tk.PhotoImage(file=path + extraPath + r"/Assets/boat-end.gif")
        self.boatEnd_Image = self.boatEnd_Image.subsample(resize_factor, resize_factor)

        self.boatEnd_Image_turned = tk.PhotoImage(file=path + extraPath + r"/Assets/boat-end-turned.png")
        self.boatEnd_Image_turned = self.boatEnd_Image_turned.subsample(resize_factor, resize_factor)

        self.boatEndReversed_Image = tk.PhotoImage(file=path + extraPath + r"/Assets/boat-end-reversed.png")
        self.boatEndReversed_Image = self.boatEndReversed_Image.subsample(resize_factor, resize_factor)

        self.boatEndReversed_Image_turned = tk.PhotoImage(file=path + extraPath + r"/Assets/boat-end-reversed-turned.png")
        self.boatEndReversed_Image_turned = self.boatEndReversed_Image_turned.subsample(resize_factor, resize_factor)

        self.boatMiddle_Image = tk.PhotoImage(file=path + extraPath + r"/Assets/boat-middle.gif")
        self.boatMiddle_Image = self.boatMiddle_Image.subsample(resize_factor, resize_factor)

        self.boatMiddle_Image_turned = tk.PhotoImage(file=path + extraPath + r"/Assets/boat-middle-turned.png")
        self.boatMiddle_Image_turned = self.boatMiddle_Image_turned.subsample(resize_factor, resize_factor)

        self.Cross_Image = tk.PhotoImage(file=path + extraPath + r"/Assets/cross.png")
        self.Cross_Image = self.Cross_Image.subsample(resize_factor, resize_factor)

        self.WhiteCross_Image = tk.PhotoImage(file=path + extraPath + r"/Assets/whitecross.png")
        self.WhiteCross_Image = self.WhiteCross_Image.subsample(resize_factor, resize_factor)

        self.boatList = BoatSelectListbox(self.window, self.listOfBoats)

        self.boatList.grid(column=1, row=1, sticky=tk.NE)

        self.statusFrame = Tableau(self.window, StatusBtn, self.water_image)
        self.TargetingFrame = Tableau(self.window, TargetingBtn, self.water_image)

        self.statusFrame.grid(column=0, row=0)
        self.TargetingFrame.grid(column=3, row=0)

        self.size = 0

        self.allBoatsPlaced = False

        self.playerRound = True
        self.robot = Robot(self)

    """
    # Gere l'instance de Tableau, soit self.TargetingFrame.
    # Fonction pour attaquer.
    def events_get_button_coords(self):
        while self.running:
            for r in range(self.targetingFrame.rows):
                for c in range(self.targetingFrame.columns):
                    b = self.targetingFrame.tableau[r][c]
                    if b.clicked:
                        self.coord = b.get_coord()
                        print(self.coord)
                    b.cancel()
    """
    # Gere l'instance de BoatSelectListbox, soit self.boatlist
    def events_get_boat_type(self):
        while self.running and self.MODE == 0: # MODE = 0 donc on est au stade placage de bateaux.
            for button in self.boatList.boats_list:
                if button.clicked:
                    self.size = button.get_boat_size()
                    print(self.size)
                button.cancel()

    def placement_bateaux(self):
        while self.running and self.MODE == 0: # MODE = 0 donc on est au stade placage de bateaux.
            # On fait une grosse boucle sa mere pour pouvoir placer les bateaux, si on peut.
            for r in range(self.statusFrame.rows):
                for c in range(self.statusFrame.columns):
                    b = self.statusFrame.tableau[r][c]
                    if b.clicked:
                        self.coord = b.get_coord()
                        print(self.coord)
                        print(self.size)
                        print("Orientation: " + str(self.boatList.BoatSpinBtnCallable.CheckButtonValue.get()))
                        bateau = Bateau(self.size, self.boatList.BoatSpinBtnCallable.CheckButtonValue.get(), self.coord[1], self.coord[0], f"Juan Pedro {len(self.matrice_joueur.bateaux)}")
                        if self.size != 0: #On vérifie si le bateau est bien placé
                            if self.matrice_joueur.placer(bateau, self): #On place le bateau
                                for button in self.boatList.boats_list: #Si le bateau s'est bien placé: on désactive le bouton de séléction du bateau
                                    if ((button.get_boat_size() == self.size) and (str(button["state"]) != "disabled")):
                                        button.disableBtn()
                                        self.size = 0
                                        break

                        self.matrice_joueur.print_matrice()
                        """
                        if self.boatList.BoatSpinBtnCallable.CheckButtonValue.get() == 0: self.afficher_bateaux_horizontal()
                        elif self.boatList.BoatSpinBtnCallable.CheckButtonValue.get() == 1: self.afficher_bateaux_vertical()
                        """

                        print("Compteur: " + str(len(self.matrice_joueur.bateaux)))
                        print(self.matrice_joueur.bateaux)
                        if len(self.matrice_joueur.bateaux) == len(self.listOfBoats):#On regarde si tous les bateaux ont été placés
                            self.boatList.BoatConfirmPlacementBtnCallable.enableBtn()
                            self.allBoatsPlaced = True

                        b.cancel()
            if self.boatList.BoatUndoBtnCallable.clicked: #Le bouton cancel fait partie de la phase du placement de bateaux
                if len(self.matrice_joueur.bateaux) != 0: #Au cas où il y a un missclick de la part du joueur
                    self.boatList.BoatConfirmPlacementBtnCallable.disableBtn() #Tant que tous les bateaux ne sont pas placés, on ne passe pas à la prochaine phase.
                    for button in self.boatList.boats_list: #On réactive le bouton de séléction du bateau
                        if ((button.get_boat_size() == self.matrice_joueur.bateaux[-1].l) and (str(button["state"]) == "disabled")):
                            button.enableBtn()
                            break
                    self.allBoatsPlaced = False
                    self.matrice_joueur.enlever(self.matrice_joueur.bateaux[-1], self) #On prend le dérnier élément de la liste, normalement le plus récent
                    self.matrice_joueur.print_matrice()
                    self.boatList.BoatUndoBtnCallable.cancel();

            if self.allBoatsPlaced:
                if self.boatList.BoatConfirmPlacementBtnCallable.clicked:
                    print("Passage à la phase suivante...") #On passe à la prochaine phase
                    self.MODE = 1
                    self.robot.placement_bateaux_IA()
                    self.boatList.BoatConfirmPlacementBtnCallable.cancel()

        self.combat() #Pour l'instant je mets ça là

    def combat(self):
        for r in range(self.statusFrame.rows):
            for c in range(self.statusFrame.columns):
                self.statusFrame.tableau[r][c].disableBtn()

        while self.running and self.MODE == 1: # MODE = 1 donc on est au stade combat.
            #print("Fight")
            if self.playerRound:
                for r in range(self.TargetingFrame.rows):
                    for c in range(self.TargetingFrame.columns):
                        b = self.TargetingFrame.tableau[r][c]
                        if b.clicked:
                            if self.matrice_ordinateur.prendre_degat(c, r, self.TargetingFrame, self.WhiteCross_Image, self.Cross_Image) != 0: #Si le tir s'est fait, on passe au tour de l'IA
                                if self.matrice_ordinateur.mort == True:
                                    FenetreFin = FenetreDeFin(self.window, "Le joueur")
                                    self.MODE = 2
                                print(f"La matrice est morte: {self.matrice_ordinateur.mort}")
                                #self.matrice_ordinateur.tirer()
                                #self.matrice_ordinateur.after(2000,self.matrice_ordinateur.disparait,self.Cross_Image)
                                self.playerRound = False
                            b.cancel()
            else:
                self.robot.attaqueIAMoyenne()
                self.playerRound = True
                print("\nTour du Joueur")
                if self.matrice_joueur.mort == True:
                    FenetreFin = FenetreDeFin(self.window, "L'ordinateur")
                    self.MODE = 2

    def run(self):
        events1 = threading.Thread(target=self.placement_bateaux)
        events1.start()

        events2 = threading.Thread(target=self.events_get_boat_type)
        events2.start()

        """
        events3 = threading.Thread(target=self.combat())
        events3.start()
        """

        self.window.mainloop()
        self.running = False

class Robot():
    def __init__(self, Jeu):
        self.IAMoyenneTraque = 0 #Si un bateau est touché, l'IA de niveau moyen passe en mode rechercheTraque (=1) jusquà qu'il trouve une traque (=2)
        self.ordre = 0 #Pour l'IA moyenne, On va chercher autour du tir réussi: 0: gauche, 1: bas, 2: droite, 3: haut
        self.offset = 2
        self.Jeu = Jeu

    def placement_bateaux_IA(self): #Fonction qui place alléatoirement les bateaux pour l'IA
        for bateauDeListe in self.Jeu.listOfBoats: #Pour chaque bateau proposé
            bateau = Bateau(bateauDeListe, randint(0, 1), randint(0, self.Jeu.TargetingFrame.columns-1), randint(0, self.Jeu.TargetingFrame.rows-1), f"{bateauDeListe} AI boat")
            while not self.Jeu.matrice_ordinateur.placer(bateau):  #Si le bateau ne se place pas, on recommence
                bateau = Bateau(bateauDeListe, randint(0, 1), randint(0, self.Jeu.TargetingFrame.columns-1), randint(0, self.Jeu.TargetingFrame.rows-1), f"{bateauDeListe} AI boat")
        print("Voici la matrice de l'IA:")
        self.Jeu.matrice_ordinateur.print_matrice()

    def TirRandom(self): #L'IA tire au hazard
        self.x = randint(-1, self.Jeu.TargetingFrame.columns-1)
        self.y = randint(-1, self.Jeu.TargetingFrame.rows-1)
        self.résultat_tir =self.Jeu.matrice_joueur.prendre_degat(self.x, self.y, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)
        while self.résultat_tir == 0:
            print(f"L'IA a déjà tiré là. en {self.x}; {self.y}. Car {self.Jeu.matrice_ordinateur.table[self.x][self.y]}")
            self.y = randint(-1, self.Jeu.TargetingFrame.columns-1)
            self.x = randint(-1, self.Jeu.TargetingFrame.rows-1)
            self.résultat_tir =self.Jeu.matrice_joueur.prendre_degat(self.x, self.y, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)
        print(f"\nAttaque en {self.x}; {self.y} de l'IA. Car {self.Jeu.matrice_ordinateur.table[self.x][self.y]}")
        return self.résultat_tir

    def attaqueIAMoyenne(self):
        if self.IAMoyenneTraque == 1:
            self.RechercheTraque()
        elif self.IAMoyenneTraque == 2:
            self.traqueTrouvée()
        elif self.IAMoyenneTraque == 0: 
            print("L'IA tire au hazard")
            if self.TirRandom() == 2:
                print("On commence à traquer le bateau")
                self.IAMoyenneTraque = 1

    def RechercheTraque(self): #On commenc par tirer autour de la cellule touchée pour trouver le reste du bateau

        if self.ordre == 0:#gauche
            print(f"Ordre: {self.ordre}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x-1, self.y, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)#On tire et enregistre le résultat du tir
            print(f"Résultat tir: {self.résultat_tir}")
            if self.résultat_tir == 2: #Si on touche une autre cellule, on va passer à une prochaine fase de l'IA
                self.IAMoyenneTraque = 2
                print("On a la traque du bateau")
                return
            if self.résultat_tir == 0:
               self.ordre += 1 
            if self.résultat_tir == 3: 
                self.IAMoyenneTraque = 0
                return #Condition de panique au cas où l'IA tire là ouù elle en devrait pas
        print(f"Or {self.ordre}")

        if self.ordre == 1:#bas
            print(f"Ordre: {self.ordre}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x, self.y+1, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)
            print(f"Résultat tir: {self.résultat_tir}")
            if self.résultat_tir == 2: 
                self.IAMoyenneTraque = 2
                print("On a la traque du bateau")
                return
            if self.résultat_tir == 0:
               self.ordre += 1
            if self.résultat_tir == 3:
                self.IAMoyenneTraque = 0
                return #Condition de panique au cas où l'IA tire là ouù elle en devrait pas
        print(f"Or {self.ordre}")

        if self.ordre == 2:#droite
            print(f"Ordre: {self.ordre}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x+1, self.y, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)
            print(f"Résultat tir: {self.résultat_tir}")
            if self.résultat_tir == 2: 
                self.IAMoyenneTraque = 2
                print("On a la traque du bateau")
                return
            if self.résultat_tir == 0:
               self.ordre += 1 
            if self.résultat_tir == 3:
                self.IAMoyenneTraque = 0
                return #Condition de panique au cas où l'IA tire là ouù elle en devrait pas
        print(f"Or {self.ordre}")

        if self.ordre == 3:#haut
            print(f"Ordre: {self.ordre}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x, self.y-1, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)
            print(f"Résultat tir: {self.résultat_tir}")
            if self.résultat_tir == 2: 
                self.IAMoyenneTraque = 2
                print("On a la traque du bateau")
                return
            if self.résultat_tir == 0:
               self.ordre += 1 
            if self.résultat_tir == 3:
                self.IAMoyenneTraque = 0
                return #Condition de panique au cas où l'IA tire là ouù elle en devrait pas

        if self.ordre > 3: self.ordre = 0

        if self.ordre == 0:#gauche
            print(f"Ordre: {self.ordre}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x-1, self.y, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)#On tire et enregistre le résultat du tir
            print(f"Résultat tir: {self.résultat_tir}")
            if self.résultat_tir == 2: #Si on touche une autre cellule, on va passer à une prochaine fase de l'IA
                self.IAMoyenneTraque = 2
                print("On a la traque du bateau")
                return
            if self.résultat_tir == 3: 
                self.IAMoyenneTraque = 0
                return #Condition de panique au cas où l'IA tire là ouù elle en devrait pas

        self.ordre += 1 #On tourne à chaque attaque
        if self.ordre > 3: self.ordre = 0
        
    def traqueTrouvée(self):

        if self.ordre == 0:#Gauche
            print(f"Ordre: {self.ordre}")
            print(f"x:{self.x}, y:{self.y}")
            print(f"Offset: {self.offset}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x-self.offset, self.y, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)#On tire et enregistre le résultat du tir
            print(f"\nAttaque en {self.x+self.offset}; {self.y} de l'IA")
            print(f"Résultat: {self.résultat_tir}")
            if self.résultat_tir == 2: 
                self.offset +=1#Si ça touche mais que ça ne coule pas, on continue à avancer
                print("Offset increase")
                return
            if self.résultat_tir == 3: 
                self.IAMoyenneTraque = 0
                self.offset = 2
            if self.résultat_tir == 1: #Si on touche de l'eau sans couler le bateau, on part chercher les bouts restants dans la direction opposée
                self.offset = 1 #self.offset nous permet de ne pas oublier d'où on a commencé à tirer
                self.ordre = 2 #Droite
                return
            if self.résultat_tir == 0:
                self.offset = 1
                self.ordre = 2 #Droite
                self.attaqueIAMoyenne()
                return
            
        if self.ordre == 1:#Bas
            print(f"Ordre: {self.ordre}")
            print(f"x:{self.x}, y:{self.y}")
            print(f"Offset: {self.offset}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x, self.y+self.offset, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)
            print(f"\nAttaque en {self.x}; {self.y+self.offset} de l'IA")
            print(f"Résultat: {self.résultat_tir}")
            if self.résultat_tir == 2: 
                self.offset +=1
                print("Offset increase")
                return
            if self.résultat_tir == 3:
                self.IAMoyenneTraque = 0
                self.offset = 2
                
            if self.résultat_tir == 1: 
                self.offset = 1
                self.ordre = 3 #Haut
                return
            if self.résultat_tir == 0:
                self.offset = 1
                self.ordre = 3 #Haut
                self.attaqueIAMoyenne()
                return

        if self.ordre == 2:#Droite
            print(f"Ordre: {self.ordre}")
            print(f"x:{self.x}, y:{self.y}")
            print(f"Offset: {self.offset}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x+self.offset, self.y, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)
            print(f"\nAttaque en {self.x+self.offset}; {self.y} de l'IA")
            print(f"Résultat: {self.résultat_tir}")
            if self.résultat_tir == 2: 
                self.offset +=1
                print("Offset increase")
                return
            if self.résultat_tir == 3:
                self.IAMoyenneTraque = 0
                self.offset = 2
            if self.résultat_tir == 1: 
                self.offset = 1
                self.ordre = 0 #Gauche
                return
            if self.résultat_tir == 0:
                self.offset = 1
                self.ordre = 0 #Gauche
                self.attaqueIAMoyenne()
                return

        if self.ordre == 3:#Haut
            print(f"Ordre: {self.ordre}")
            print(f"x:{self.x}, y:{self.y}")
            print(f"Offset: {self.offset}")
            self.résultat_tir = self.Jeu.matrice_joueur.prendre_degat(self.x, self.y-self.offset, self.Jeu.statusFrame, self.Jeu.WhiteCross_Image, self.Jeu.Cross_Image)
            print(f"\nAttaque en {self.x}; {self.y-self.offset} de l'IA")
            print(f"Résultat: {self.résultat_tir} \n")
            if self.résultat_tir == 2: 
                self.offset +=1
                print("Offset increase")
                return
            if self.résultat_tir == 3:
                self.IAMoyenneTraque = 0
                self.offset = 2

            if self.résultat_tir == 1: 
                self.offset = 1
                self.ordre = 1 #Bas
                return
            if self.résultat_tir == 0:
                self.offset = 1
                self.ordre = 1 #Bas
                self.attaqueIAMoyenne()
                return

jeu = Jeu()
jeu.run()