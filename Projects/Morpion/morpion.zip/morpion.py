from termcolor import colored
from colorama import Fore, Style

#On définit la grille du morpion sous forme de liste
grille = [0, 0, 0,
          0, 0, 0,
          0, 0, 0]

#On définit le string de la grille du morpion sous forme de liste aussi
grilleAffichée = ["", "", "",
                  "", "", "",
                  "", "", ""]

#Liste des conditions de victoire
ConditionsDeVictoire = [
                        [0, 3, 6], 
                        [1, 4, 7],
                        [2, 5, 8],
                        [0, 1, 2],
                        [3, 4, 5],
                        [6, 7, 8],
                        [2, 4, 6],
                        [0, 4, 8]
                        ]

#On affiche un tutoriel à chaque lancement de programme afin de ne pas surcharger l'interface tous les débuts de partie 
print("""
 1 | 2 | 3
---𐠒---𐠒---
 4 | 5 | 6
---𐠒---𐠒---
 7 | 8 | 9

Entrez le numéro correspondant à une de ces cases pour y placer votre pièce.
""")


#Procédure d'affichage de la grille
def AfficheGrille():
   
    #On initialize localement les 3 lignes possédant l'information du statut la grille
    ligne1 = ""
    ligne2 = ""
    ligne3 = ""

    #On adapte les symboles de la grille affichée aux valeurs de la grille
    for i in range(9):
        #1 correspond à "X"
        if grille[i] == 1:
            grilleAffichée[i] = colored("X", "blue")
        #2 correspond à "O"
        elif grille[i] == 2:
            grilleAffichée[i] = colored("O", "red")
        #Si on a autre chose, on met un espace vide
        else:
            grilleAffichée[i] = " "

    #On génère les 3 lignes composées contenant les symboles
    ligne1 += (str(grilleAffichée[0]) + " | " + str(grilleAffichée[1]) + " | " + str(grilleAffichée[2]))
    ligne2 += (str(grilleAffichée[3]) + " | " + str(grilleAffichée[4]) + " | " + str(grilleAffichée[5]))
    ligne3 += (str(grilleAffichée[6]) + " | " + str(grilleAffichée[7]) + " | " + str(grilleAffichée[8]))

    #On affiche la grille actualisée (Incluant des ajouts pour aérer)
    print("")
    print(ligne1)
    print("--𐠒---𐠒--")
    print(ligne2)
    print("--𐠒---𐠒--")
    print(ligne3)
    print("")


#Fonction de gestion des entrées du Joueur 1
def P1InputHandler():
        #On définit la variable au tout début
        P1Input = int()

        #On empêche le joueur de donner autre chose que des nombres
        while True:
            P1RawInput = input(colored("Joueur 1", "blue") + ", placez votre croix: ")

            # .isdigit() vérifie si P1RawInput est un intègre
            if P1RawInput.isdigit() == True:
                P1Input = int(P1RawInput)
                break
            #Sinon on laisse tourner la boucle
            else:
                print(colored("Cette commande n'est pas valable.\n", "red"))

        #On vérifie que le nombre se trouve dans la grille
        if 9 >= P1Input and P1Input >= 1 :
            P1Input -= 1

            #On vérifie que la place ne soit pas déjà prise
            if grille[P1Input] == 1 or grille[P1Input] == 2:
                print(colored("Il y a déjà quelque chose à cet endroit.\n", "red"))
                P1InputHandler()
            #Et si la commande est valide:
            else:
                grille[P1Input] = 1
                return(int(P1Input))
        else:
            print(colored("Cette place n'existe pas.\n", "red"))
            P1InputHandler()

#Gestion des entrées du Joueur 2
def P2InputHandler():
        P2Input = int()

        while True:
            P2RawInput = input(colored("Joueur 2", "red") + ", placez votre cercle: ")

            # .isdigit() vérifie si P2RawInput est un intègre
            if P2RawInput.isdigit() == True:
                P2Input = int(P2RawInput)
                break
            #Sinon on laisse tourner la boucle
            else:
                print(colored("Cette commande n'est pas valable.\n", "red"))


        #On vérifie que le nombre se trouve dans la grille
        if 9 >= P2Input and P2Input >= 1 :
            P2Input -= 1

            #On vérifie que la place ne soit pas déjà prise
            if grille[P2Input] == 1 or grille[P2Input] == 2:
                print(colored("Il y a déjà quelque chose à cet endroit.\n", "red"))
                P2InputHandler()
            #Et si la commande est valide:
            else:
                grille[P2Input] = 2
                return(int(P2Input))
        else:
            print(colored("Cette place n'existe pas.\n", "red"))
            P2InputHandler()

#Fonction de la demande de revanche
def rematch():
    while True:
        #On précise qu'on parle de LA grille
        global grille

        rematch = input("Voulez-vous rejouer?(Y/N) ")

        #On prend en compte plusieurs cas de figure
        if rematch == "Y" or rematch == "y":
            #Reset de la grille suivi d'un return qui dit qu'il ne faut pas fermer le programme
            grille = [0, 0, 0,
                      0, 0, 0,
                      0, 0, 0]
            return(False)
            break

        elif rematch == "N" or rematch == "n":
            #On ferme le programme
            return(True)
            break

        #Si on ne peut pas identifier la commande
        else:
            print(colored("La commande n'est pas valide. \n", "red"))

#Fonction pour vérifier si quelqu'un a gagné
def WinConditionHandler():

    for condition in range(len(ConditionsDeVictoire)):

        """
        print(grille[ConditionsDeVictoire[condition][0]])
        print(grille[ConditionsDeVictoire[condition][1]])
        print(grille[ConditionsDeVictoire[condition][2]])
        """

        # ConditionsDeVictoire[condition][0]] correspond à une place dans la grille. Ici on vérifie que les trois places faisant partie d'une des conditions ont la même valeur
        if grille[ConditionsDeVictoire[condition][0]] == grille[ConditionsDeVictoire[condition][1]] == grille[ConditionsDeVictoire[condition][2]]:

            #On vérifie quel joueur c'est
            if grille[ConditionsDeVictoire[condition][0]] == 1:
                print(Fore.BLUE + "Joueur 1 a gagné!\n", Style.RESET_ALL)
                #Dans le cas des deux joueurs on appelle la fonction qui propose une revanche, ce return détermine si la partie est finie ou pas
                return(rematch())

            elif grille[ConditionsDeVictoire[condition][0]] == 2:
                print(Fore.RED + "Joueur 2 a gagné!\n", Style.RESET_ALL)
                return(rematch())

    #Sinon on ne fait rien
    return(False)


fini = False
#Loop de jeu principal
while fini == False:

    #Tour du joueur 1 suivi de l'affichage de la grille
    P1InputHandler()
    AfficheGrille()

    #On vérifie la victoire après chaque tour
    fini = WinConditionHandler()
    if fini == True:
        break
    
    #On vérifie si la grille n'est pas déjà pleine
    if 0 not in grille:
        #Si elle l'est: on indique une égalité
        print(colored("Egalité!\n", "yellow"))

        #On vérifie si on veut une revanche
        fini = rematch()
        if fini == True:
            break

    #Tour du joueur 2 suivi de l'affichage de la grille
    P2InputHandler()
    AfficheGrille()

    #On vérifie la victoire après chaque tour
    fini = WinConditionHandler()
    if fini == True:
        break

    #On vérifie si la grille ne soit pas déjà pleine
    if 0 not in grille:
        #Si elle l'est: on indique une égalité
        print(colored("Egalité!\n", "yellow"))

        #On vérifie si on veut une revanche
        fini = rematch()
        if fini == True:
            break

